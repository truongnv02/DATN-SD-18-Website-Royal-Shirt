package com.poly.datn.sd18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatnSd18WebsiteRoyalShirtApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatnSd18WebsiteRoyalShirtApplication.class, args);
	}

}
